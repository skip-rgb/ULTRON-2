package com.ultron.assistant

import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

/**
 * Ultron's internet brain. No API keys needed:
 *  - Questions -> DuckDuckGo Instant Answers, Wikipedia as fallback
 *  - Places   -> OpenStreetMap (Nominatim)
 *  - Weather  -> wttr.in
 * All calls run off the main thread; results come back on it.
 */
object Brain {

    private val main = Handler(Looper.getMainLooper())

    private fun get(url: String, userAgent: String? = null): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            if (userAgent != null) conn.setRequestProperty("User-Agent", userAgent)
            if (conn.responseCode != 200) return null
            val reader = BufferedReader(InputStreamReader(conn.inputStream))
            val out = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) out.append(line)
            reader.close()
            out.toString()
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun runAsync(work: () -> String?, done: (String?) -> Unit) {
        Thread {
            val result = work()
            main.post { done(result) }
        }.start()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Short spoken answer to a general question, or null if nothing found. */
    fun answerQuestion(question: String, done: (String?) -> Unit) {
        runAsync({
            // 1) DuckDuckGo Instant Answers
            val ddg = get("https://api.duckduckgo.com/?q=${enc(question)}&format=json&no_html=1&skip_disambig=1")
            if (ddg != null) {
                val json = JSONObject(ddg)
                val abstract = json.optString("AbstractText", "")
                if (abstract.isNotBlank()) return@runAsync shorten(abstract)
                val answer = json.optString("Answer", "")
                if (answer.isNotBlank()) return@runAsync shorten(answer)
                val topics = json.optJSONArray("RelatedTopics")
                if (topics != null && topics.length() > 0) {
                    val first = topics.optJSONObject(0)?.optString("Text", "") ?: ""
                    if (first.isNotBlank()) return@runAsync shorten(first)
                }
            }
            // 2) Wikipedia summary
            val topic = question
                .replace(Regex("^(what is|who is|tell me about|define|meaning of)\\s+", RegexOption.IGNORE_CASE), "")
                .trim()
            val wiki = get("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(topic.replace(' ', '_'))}")
            if (wiki != null) {
                val extract = JSONObject(wiki).optString("extract", "")
                if (extract.isNotBlank()) return@runAsync shorten(extract)
            }
            null
        }, done)
    }

    /** A place's name + coordinates, or null. */
    fun findPlace(query: String, done: (Place?) -> Unit) {
        Thread {
            val json = get(
                "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${enc(query)}",
                userAgent = "UltronAssistant/1.0"
            )
            var place: Place? = null
            if (json != null) {
                val arr = org.json.JSONArray(json)
                if (arr.length() > 0) {
                    val o = arr.getJSONObject(0)
                    place = Place(
                        name = o.optString("display_name", query),
                        lat = o.optString("lat", ""),
                        lon = o.optString("lon", "")
                    )
                }
            }
            main.post { done(place) }
        }.start()
    }

    /** One-line weather for a city, or null. */
    fun weather(city: String, done: (String?) -> Unit) {
        runAsync({
            val json = get("https://wttr.in/${enc(city)}?format=j1") ?: return@runAsync null
            val current = JSONObject(json).optJSONArray("current_condition")?.optJSONObject(0)
                ?: return@runAsync null
            val temp = current.optString("temp_C", "")
            val desc = current.optJSONArray("weatherDesc")?.optJSONObject(0)?.optString("value", "")
            if (temp.isBlank()) null else "It is $temp degrees and $desc in $city."
        }, done)
    }

    private fun shorten(text: String, maxLen: Int = 400): String {
        if (text.length <= maxLen) return text
        val cut = text.substring(0, maxLen)
        val lastDot = cut.lastIndexOf(". ")
        return if (lastDot > 100) cut.substring(0, lastDot + 1) else "$cut..."
    }

    data class Place(val name: String, val lat: String, val lon: String)
}
