package com.ultron.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Opens installed apps by spoken name, e.g. "open whatsapp".
 * First tries apps actually installed on the phone, then a list of
 * well-known package names as a fallback.
 */
object AppLauncher {

    private val knownPackages = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "chrome" to "com.android.chrome",
        "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient",
        "telegram" to "org.telegram.messenger",
        "snapchat" to "com.snapchat.android",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "amazon" to "in.amazon.mShop.android.shopping",
        "paytm" to "net.one97.paytm",
        "phonepe" to "com.phonepe.app",
        "gpay" to "com.google.android.apps.nbu.paisa.user",
        "google pay" to "com.google.android.apps.nbu.paisa.user",
        "settings" to "com.android.settings",
        "camera" to "com.android.camera",
        "gallery" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "drive" to "com.google.android.apps.docs",
        "play store" to "com.android.vending",
        "music" to "com.google.android.apps.youtube.music"
    )

    /** Returns true if something was launched. */
    fun openApp(context: Context, spokenName: String): Boolean {
        val name = spokenName.trim().lowercase()
        // 1) Exact known package
        knownPackages[name]?.let { pkg ->
            if (launchPackage(context, pkg)) return true
        }
        // 2) Any installed app whose label contains the spoken name
        val pm: PackageManager = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in apps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label == name || label.contains(name)) {
                if (launchPackage(context, app.packageName)) return true
            }
        }
        // 3) Known package whose key is contained in the spoken name
        for ((key, pkg) in knownPackages) {
            if (name.contains(key) && launchPackage(context, pkg)) return true
        }
        return false
    }

    private fun launchPackage(context: Context, pkg: String): Boolean {
        val intent: Intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
